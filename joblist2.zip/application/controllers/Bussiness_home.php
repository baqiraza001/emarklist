<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Bussiness_home extends Main_Controller{

	// public function __construct()
	// {
	// 	parent::__construct();
	// 	$this->load->model('company_model');
	// }
	public function index()
	{
		redirect('bussiness/home');
	}

}

?> 