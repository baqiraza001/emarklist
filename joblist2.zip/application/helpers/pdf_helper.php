<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require_once('mpdf/mpdf.php');
?>